WARN: If it does not open try to open it as administrator!
WARN: If it doesn't work as admin go to my discord server (https://discord.gg/EBDH8mBrS3) and open a ticket and I will help you!
WARN: If it does not work or the Installer.exe is deleted immediately turn off your antivirus and download the file again!
Gam3rteams